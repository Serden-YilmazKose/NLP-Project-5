Project Github repo: https://github.com/Serden-YilmazKose/NLP-Project-5

All tasks except for task 12 are found in the "NLP-course-project.ipynb file". Code for task 12 is found in "task_12.py".

To install all required libraries run: pip install -r requirements.txt

Also, in Task 10, Nvidia CUDA was used to enable GPU support for training and utilizing of our doc2vec model, if you don't have CUDA installed it will run on CPU and take for a long time.

